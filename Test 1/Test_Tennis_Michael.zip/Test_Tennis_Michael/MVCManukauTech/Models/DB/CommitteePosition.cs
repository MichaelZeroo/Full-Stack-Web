﻿using System;
using System.Collections.Generic;

namespace MVCManukauTech.Models.DB
{
    public partial class CommitteePosition
    {
        public int PositionId { get; set; }
        public string Description { get; set; }
    }
}
