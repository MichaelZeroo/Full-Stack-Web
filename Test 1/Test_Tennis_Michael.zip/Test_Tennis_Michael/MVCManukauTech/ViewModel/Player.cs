﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCManukauTech.ViewModel
{
    public class Player
    {
        public int ResultId { get; set; }
        public int TeamId { get; set; }
        public int PlayerId { get; set; }
        public int Wins { get; set; }
    }
}
